from rest_framework import viewsets, status, permissions
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate, get_user_model
from .models import Project, Sprint, Task, CommitLog, RiskAlert
from .serializers import (
    UserSerializer, UserProfileSerializer, ProjectSerializer,
    SprintSerializer, TaskSerializer, CommitLogSerializer, RiskAlertSerializer
)
from .permissions import IsProjectManager, IsOwnerOrProjectManager
from .services import ProjectIntelligenceService

User = get_user_model()

@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def register(request):
    serializer = UserSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        refresh = RefreshToken.for_user(user)
        return Response({
            'user': UserSerializer(user).data,
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        }, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def login(request):
    username = request.data.get('username')
    password = request.data.get('password')
    
    user = authenticate(username=username, password=password)
    
    if user is not None:
        refresh = RefreshToken.for_user(user)
        return Response({
            'user': UserSerializer(user).data,
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        })
    
    return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

@api_view(['GET', 'PUT'])
@permission_classes([permissions.IsAuthenticated])
def profile(request):
    if request.method == 'GET':
        serializer = UserProfileSerializer(request.user)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        serializer = UserProfileSerializer(request.user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer
    
    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsProjectManager()]
        return [permissions.IsAuthenticated()]
    
    def get_queryset(self):
        user = self.request.user
        if user.role == 'PROJECT_MANAGER':
            return Project.objects.filter(manager=user)
        else:
            return Project.objects.filter(tasks__assigned_to=user).distinct()
    
    def perform_create(self, serializer):
        serializer.save(manager=self.request.user)

class SprintViewSet(viewsets.ModelViewSet):
    queryset = Sprint.objects.all()
    serializer_class = SprintSerializer
    
    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsProjectManager()]
        return [permissions.IsAuthenticated()]
    
    def get_queryset(self):
        user = self.request.user
        if user.role == 'PROJECT_MANAGER':
            return Sprint.objects.filter(project__manager=user)
        else:
            return Sprint.objects.filter(tasks__assigned_to=user).distinct()

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    
    def get_permissions(self):
        if self.action in ['create', 'destroy']:
            return [IsProjectManager()]
        return [permissions.IsAuthenticated()]
    
    def get_queryset(self):
        user = self.request.user
        if user.role == 'PROJECT_MANAGER':
            return Task.objects.filter(project__manager=user)
        else:
            return Task.objects.filter(assigned_to=user)
    
    @action(detail=True, methods=['post'])
    def update_hours(self, request, pk=None):
        task = self.get_object()
        actual_hours = request.data.get('actual_hours')
        
        if actual_hours is not None:
            task.actual_hours = float(actual_hours)
            task.save()
            
            delay_prediction = ProjectIntelligenceService.calculate_delay_prediction(task)
            
            return Response({
                'task': TaskSerializer(task).data,
                'delay_prediction': delay_prediction
            })
        
        return Response({'error': 'actual_hours required'}, status=status.HTTP_400_BAD_REQUEST)

class CommitLogViewSet(viewsets.ModelViewSet):
    queryset = CommitLog.objects.all()
    serializer_class = CommitLogSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        if user.role == 'PROJECT_MANAGER':
            return CommitLog.objects.filter(task__project__manager=user)
        else:
            return CommitLog.objects.filter(task__assigned_to=user)

class RiskAlertViewSet(viewsets.ModelViewSet):
    queryset = RiskAlert.objects.all()
    serializer_class = RiskAlertSerializer
    permission_classes = [IsProjectManager]
    
    def get_queryset(self):
        return RiskAlert.objects.filter(project__manager=self.request.user)
    
    @action(detail=True, methods=['post'])
    def resolve(self, request, pk=None):
        alert = self.get_object()
        alert.is_resolved = True
        alert.save()
        return Response({'status': 'resolved'})

@api_view(['GET'])
@permission_classes([IsProjectManager])
def manager_dashboard(request):
    dashboard_data = ProjectIntelligenceService.generate_manager_dashboard(request.user)
    return Response(dashboard_data)

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def employee_dashboard(request):
    if request.user.role != 'EMPLOYEE':
        return Response({'error': 'Only employees can access this dashboard'}, status=status.HTTP_403_FORBIDDEN)
    
    dashboard_data = ProjectIntelligenceService.generate_employee_dashboard(request.user)
    return Response(dashboard_data)

@api_view(['POST'])
@permission_classes([IsProjectManager])
def detect_project_risks(request, project_id):
    try:
        project = Project.objects.get(id=project_id, manager=request.user)
    except Project.DoesNotExist:
        return Response({'error': 'Project not found'}, status=status.HTTP_404_NOT_FOUND)
    
    alerts = ProjectIntelligenceService.detect_blockers(project)
    
    return Response({
        'project_id': project_id,
        'new_alerts': RiskAlertSerializer(alerts, many=True).data
    })

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def performance_score(request):
    score = ProjectIntelligenceService.calculate_performance_score(request.user)
    return Response({
        'user_id': request.user.id,
        'username': request.user.username,
        'performance_score': round(score, 2)
    })
